=== Kodex Posts likes ===
Contributors: Pierre Lebedel
Tags: posts, like, dislike, voting, vote
Requires at least: 3.0
Tested up to: 4.3.1
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A simple AJaX based WordPress Plugin which allows your visitors to like or dislike posts, pages and cutom post types. 

== Description ==
The Kodex Posts likes plugin allows your visitors and logged in users to like or dislike your posts, pages, and custom post types.
The AJaX based interface is clean and fully customizable.
The Dislike button is not required, and the buttons labels are editables.
The buttons shows their counter.
Shortcodes are availables for display the buttons on your post content and for the Like counter only.
In the admin interface, columns are showing the actual count, and there is a metabox in the editon page.


== Installation ==

= Installing manually: =

1. Unzip all files to the `/wp-content/plugins/loco-translate` directory
2. Log into WordPress admin and activate the 'Loco Translate' plugin through the 'Plugins' menu
3. Go to *Loco Translate > Manage Translations* in the left-hand menu to start translating


== Screenshots ==

1. Plugin options page
2. Posts list view
3. Post edit view
4. Front-end view